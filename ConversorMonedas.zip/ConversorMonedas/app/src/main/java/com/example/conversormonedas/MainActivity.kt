package com.example.conversormonedas

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etMonto: EditText
    private lateinit var spOrigen: Spinner
    private lateinit var spDestino: Spinner
    private lateinit var tvResultado: TextView

    // Tasas relativas a 1 EUR (ejemplo)
    private val tasaPorEUR = mapOf(
        "EUR" to 1.0,
        "USD" to 1.08,
        "MXN" to 18.5,
        "ARS" to 955.0,
        "CLP" to 980.0,
        "COP" to 4400.0
    )

    private val formatoNumero: NumberFormat by lazy {
        NumberFormat.getNumberInstance(Locale.getDefault()).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etMonto = findViewById(R.id.etMonto)
        spOrigen = findViewById(R.id.spOrigen)
        spDestino = findViewById(R.id.spDestino)
        tvResultado = findViewById(R.id.tvResultado)
    }

    // 🔁 Intercambiar monedas (ultra robusto)
    fun intercambiar(view: View) {
        try {
            val adpO = spOrigen.adapter
            val adpD = spDestino.adapter
            if (adpO == null || adpD == null) {
                Toast.makeText(this, "Lista de monedas no cargada", Toast.LENGTH_SHORT).show()
                return
            }
            if (adpO.count == 0 || adpD.count == 0) {
                Toast.makeText(this, "Lista de monedas vacía", Toast.LENGTH_SHORT).show()
                return
            }
            val idxOrigen = spOrigen.selectedItemPosition.takeIf { it >= 0 } ?: 0
            val idxDestino = spDestino.selectedItemPosition.takeIf { it >= 0 } ?: 0

            val nuevoOrigen  = idxDestino.coerceIn(0, adpO.count - 1)
            val nuevoDestino = idxOrigen.coerceIn(0, adpD.count - 1)

            spOrigen.setSelection(nuevoOrigen,  true)
            spDestino.setSelection(nuevoDestino, true)
        } catch (e: Exception) {
            Toast.makeText(this, "Error al intercambiar monedas", Toast.LENGTH_SHORT).show()
        }
    }

    // 🧹 Limpiar
    fun limpiar(view: View) {
        etMonto.text?.clear()
        tvResultado.text = ""
        etMonto.requestFocus()
    }

    // 💱 Convertir
    fun convertir(view: View) {
        val texto = etMonto.text?.toString()?.trim().orEmpty()
        if (texto.isEmpty()) {
            Toast.makeText(this, "Introduce un monto para convertir", Toast.LENGTH_SHORT).show()
            return
        }
        val monto = texto.toDoubleOrNull()
        if (monto == null) {
            Toast.makeText(this, "Monto no válido", Toast.LENGTH_SHORT).show()
            return
        }

        val codOrigen = obtenerCodigo(spOrigen.selectedItem?.toString().orEmpty())
        val codDestino = obtenerCodigo(spDestino.selectedItem?.toString().orEmpty())
        if (codOrigen.isEmpty() || codDestino.isEmpty()) {
            Toast.makeText(this, "Selecciona ambas monedas", Toast.LENGTH_SHORT).show()
            return
        }

        if (codOrigen == codDestino) {
            tvResultado.text = String.format("%.2f %s = %.2f %s", monto, codOrigen, monto, codDestino)
            return
        }

        val tasaOrigen = tasaPorEUR[codOrigen]
        val tasaDestino = tasaPorEUR[codDestino]
        if (tasaOrigen == null || tasaDestino == null) {
            Toast.makeText(this, "Moneda no soportada", Toast.LENGTH_SHORT).show()
            return
        }

        val montoEnEUR = monto / tasaOrigen
        val convertido = montoEnEUR * tasaDestino

        tvResultado.text = "${formatoNumero.format(monto)} $codOrigen = ${formatoNumero.format(convertido)} $codDestino"
    }

    // De "EUR - Euro" saca "EUR"
    private fun obtenerCodigo(textoSpinner: String): String {
        // OJO: si en tu array usaste EN DASH (–) en vez de guion (-), cambia por " – "
        val partes = textoSpinner.split(" - ")
        return partes.firstOrNull()?.trim().orEmpty()
    }
}
